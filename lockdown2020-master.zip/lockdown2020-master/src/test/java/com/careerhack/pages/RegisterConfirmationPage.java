package com.careerhack.pages;

import org.openqa.selenium.WebDriver;

public class RegisterConfirmationPage extends PageBase{

	public RegisterConfirmationPage(WebDriver driver) {
		super(driver);
	}
	

}
